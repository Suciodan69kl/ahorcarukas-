﻿using System;

internal class los_7_osqueteros 
{
    private static void Main(string[] args)
    {
        int opcion;
        Console.WriteLine("BIENVENIDO A LOS SIETE MOSQUETEROS ");
        Console.WriteLine("PRESIONA 2 VECES LA TECLA ENTER PARA IR A MENU");
        Console.ReadKey();
        Console.Clear();
        int num = 0;
        float[] vector = new float[10];
        int i = 0;

        while (i < vector.Length)
        {
            Console.WriteLine("Ingresa tus numeros y presiona 2 veces enter");
            num = int.Parse(Console.ReadLine());
            if (num >= 1 && num <= 1000)
            {
                vector[i] = num;
                i++;
            }
            else
            {
                Console.WriteLine("n");
            }
            Console.ReadKey();
        }
        Console.WriteLine("numeros del vector es:");
        foreach (int temp in vector)
        {
            Console.WriteLine(temp);
        }
        Console.ReadKey();
        Console.Clear();
        Console.WriteLine("SELECIONA LOS NUMEROS A REQUERIR");
        Console.WriteLine("1.INTERCAMBIAR LOS ELEMENTOS DE UN VECTOR");
        Console.WriteLine("2.ORDENAR DE MAYOR A MENOR");
        Console.WriteLine("3.AVERIGUA SI UN LISTA DE NUMEROS ESTA ORDENADA DE MANERA CRECIENTE");
        Console.WriteLine("4.AVERIGUA SI EN LA LISTA HAY NUMEROS REPETIDOS");
        Console.WriteLine("5.ORDENA DE MENOR A MAYOR");
        Console.WriteLine("6.DADA UNA LISTA DE N NUMEROS AVERIGUE SI EL NUMERO T ESTA EN LA LISTA");
        Console.WriteLine("7.HALLAR EL PROMEDIO DE UN VECTOR");
        opcion = int.Parse(Console.ReadLine());
        switch (opcion)
        {
            case 1:
                int cam = vector.Length - 1;
                string num1 = "";

                while (cam >= 0)
                {

                    num1 = num1 + vector[cam];
                    cam = cam - 1;

                }

                Console.WriteLine("El numero invertido es: " + num1);

                Console.ReadKey();
                break;
            case 2:
                Array.Sort(vector);
                Array.Reverse(vector);
                Console.WriteLine("tu vector ordenado es:");
                for (int k = 0; k < vector.Length; k++)
                { 
                    Console.WriteLine(vector[k].ToString());
                }
                break;
            case 3:
              

                break;
            case 4:
                bool rep = false;
                for (var a = 0; a < vector.Length; a++)
                {
                    float m = vector[a];
                    int c = a + 1;
                    for (int p = c; p < vector.Length; p++)
                    {
                        float r = vector[p];
                        if (m == r)
                        {
                            rep = true;
                            Console.WriteLine("el numero   " + m + "   esta repetido en el vector");
                        }
                    }
                }
                if (rep == false)
                {
                    Console.WriteLine("no hay numeros repetidos en la lista");
                }
                break;
            case 5:
                Array.Sort(vector);
                Console.WriteLine("tu ordenamiento de menor a mayor es: ");
                Console.ReadKey();
                for (int h = 0; h < vector.Length; h++)
                {


                    Console.WriteLine(vector[h].ToString());
                }

                break;
            case 6:
               
                break;
            case 7:

                double sumatoria = 0;
                foreach (double suma in vector)
                {
                    sumatoria += suma;
                }
                double promedio = sumatoria / vector.Length;
                Console.WriteLine("El promedio del vector es: " + promedio);
                break;

        }
    }
}